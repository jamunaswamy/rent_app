package com.example.house1;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class searchlocation extends AppCompatActivity {
    EditText e1;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchlocation);
        b=(Button)findViewById(R.id.b1);
        e1=(EditText) findViewById(R.id.editText2);
        String loc=getIntent().getStringExtra("addres");
         e1.setText(loc);





        b.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Uri gmmIntentUri = Uri.parse(("geo:0,0?q=" + e1.getText().toString()));
                Intent mapIntent=new Intent(Intent.ACTION_VIEW,gmmIntentUri);
                startActivity(mapIntent);
            }
        });

    }
}
