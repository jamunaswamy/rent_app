package com.example.house1;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class details extends AppCompatActivity {
    TextView tv;
    EditText e1;
    Button b1;
    dbhelperclass dbhobj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details2);
        dbhobj = new dbhelperclass(this);
        tv = (TextView) findViewById(R.id.view);

        b1=(Button)findViewById(R.id.search);


        String na=getIntent().getStringExtra("name");


        String cr = dbhobj.getdata1(na);
        tv.setText(cr);
        tv.setMovementMethod(new ScrollingMovementMethod());
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ad=getIntent().getStringExtra("address");
                //Intent i=new Intent(details.this,searchlocation.class);
               // i.putExtra("addres",ad+"");
                //startActivity(i);

                Uri gmmIntentUri = Uri.parse(("geo:0,0?q=" +ad));
                Intent mapIntent=new Intent(Intent.ACTION_VIEW,gmmIntentUri);
                startActivity(mapIntent);
            }
        });


    }
}
