package com.example.house1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class o_login extends AppCompatActivity {
    Button login, register, changepassword;
    EditText username, password;
    dbhelperclass mdb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_o_login);

        mdb = new dbhelperclass(this);

        login = (Button) findViewById(R.id.b1);
        username = (EditText) findViewById(R.id.user);
        password = (EditText) findViewById(R.id.pass);
        register = (Button) findViewById(R.id.b2);
        changepassword = (Button) findViewById(R.id.b3);


        login = (Button) findViewById(R.id.b1);
        username = (EditText) findViewById(R.id.user);
        password = (EditText) findViewById(R.id.pass);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username1 = username.getText().toString();
                String password1 = password.getText().toString();


                String storedPassword = mdb.getSinlgeEntry1(username1);

// check if the Stored password matches with Password entered by user
                if (password1.equals(storedPassword)) {
                    Toast.makeText(o_login.this, "Congrats: Login Successfull", Toast.LENGTH_LONG).show();
                    Intent in = new Intent(o_login.this, owener_spinner.class);
                    startActivity(in);


                } else {
                    Toast.makeText(o_login.this, "User Name or Password does not match", Toast.LENGTH_LONG).show();
                }
            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(o_login.this, o_signup.class);
                startActivity(intent);
            }
        });

        changepassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(o_login.this, changepassword.class);
                startActivity(intent);

            }
        });
    }




    public boolean onCreateOptionsMenu (Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.login, menu);
        return true;
    }

    public boolean onOptionsItemSelected (MenuItem item)
    {
        switch (item.getItemId()) {
            case R.id.admin:
                Intent intent=new Intent(o_login.this,adminlogin.class);
                startActivity(intent);
                break;

            case R.id.about:
                android.app.AlertDialog.Builder dialogBuilder = new android.app.AlertDialog.Builder(this);
                dialogBuilder.setIcon(R.drawable.home1);
                dialogBuilder.setTitle(R.string.app_name);
                dialogBuilder.setMessage("House For Sale is an app for Android smart phones.It is an application for the user where the user can search for the different types of houses for sale i.e, 1BHK, 2BHK and 3BHK houses and also user can view the complete details of the house.\n");
                dialogBuilder.create();
                dialogBuilder.show();
                return true;
            case R.id.owner:
                Intent i=new Intent(o_login.this,o_login.class);
                startActivity(i);
                break;
            case R.id.user:
                Intent i1=new Intent(o_login.this,loginpage.class);
                startActivity(i1);
        }
        return false;
    }



}

