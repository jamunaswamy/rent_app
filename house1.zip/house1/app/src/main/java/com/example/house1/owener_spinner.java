package com.example.house1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class owener_spinner extends AppCompatActivity {
Spinner sv;
String [] array={"select","insert","delete","update","View"};
String a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owener_spinner);


        sv=(Spinner) findViewById(R.id.spinner);
        ArrayAdapter adp=new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,array);
        adp.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        sv.setAdapter(adp);
        sv.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                a=(String)adapterView.getSelectedItem();
                Toast.makeText(getApplicationContext(),a,Toast.LENGTH_LONG).show();
                switch (a){

                    case "insert":
                        Intent intent = new Intent(owener_spinner.this, house.class);
                        startActivity(intent);
                        break;

                   case "delete":
                        Intent intent1 = new Intent(owener_spinner.this, owner_delete.class);
                        startActivity(intent1);
                        break;

                    case "update":
                        Intent intent2 = new Intent(owener_spinner.this, owner_update.class);
                        startActivity(intent2);
                        break;

                    case "View":
                        Intent intent3 = new Intent(owener_spinner.this, view.class);
                        startActivity(intent3);
                        break;



                }



            }




            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


    }
    }
