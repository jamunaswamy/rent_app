package com.example.house1;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class changepassword extends AppCompatActivity {

    EditText oldpass,newpass;
    Button confirm;
    SQLiteDatabase mdb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changepassword);

        mdb=openOrCreateDatabase("abc",MODE_PRIVATE,null);

        oldpass=(EditText)findViewById(R.id.ed1);
        newpass=(EditText)findViewById(R.id.ed2);

        confirm=(Button)findViewById(R.id.button);



        confirm.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = oldpass.getText().toString();
                String newpassword = newpass.getText().toString();
                if (password.isEmpty() || newpassword.isEmpty()) {
                    Toast.makeText(changepassword.this, "enter password", Toast.LENGTH_SHORT).show();
                } else {
                    String query = "UPDATE user_table SET Password='" + newpassword + "'WHERE Password='" + password + "'";
                    mdb.execSQL(query);
                    Toast.makeText(changepassword.this, "password changed", Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(changepassword.this,loginpage.class);
                    startActivity(intent);
                }
            }
        }));

    }
}
