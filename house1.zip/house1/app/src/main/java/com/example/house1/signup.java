package com.example.house1;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class signup extends AppCompatActivity {
    private EditText username,password,confirmpassword,email,mobile;
    Button submit;
    dbhelperclass db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
         db=new dbhelperclass(this);


        submit = (Button) findViewById(R.id.sub);
        username = (EditText) findViewById(R.id.et2);
        password = (EditText) findViewById(R.id.et3);
        confirmpassword = (EditText)findViewById(R.id.et4);
        email = (EditText)findViewById(R.id.et5);
        mobile = (EditText)findViewById(R.id.et6);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username1 = username.getText().toString().trim();
                String password1 = password.getText().toString().trim();
                String confirmpassword1 = confirmpassword.getText().toString().trim();
                String email1 = email.getText().toString().trim();
                String mobile1 = mobile.getText().toString().trim();

                if (username1.length() == 0) {
                    username.setError(Constants.MISSING_NAME);
                    username.requestFocus();
                } else if (password1.length() == 0) {
                    password.setError(Constants.MISSING_PASSWORD);
                    password.requestFocus();
                } else if (password1.length() < Constants.MINIMUM_PASSWORD_LENGTH) {
                    password.setError(Constants.MINIMUM_PASSWORD);
                    password.requestFocus();

                } else if (false == isValidPassword(password1)) {
                    password.setError(Constants.INVALID_PASSWORD);
                    password.requestFocus();

                } else if (confirmpassword1.length() == 0) {
                    confirmpassword.setError(Constants.MISSING_PASSWORD);
                    confirmpassword.requestFocus();
                } else if (false == confirmpassword1.equals(password1)) {
                    confirmpassword.setError(Constants.PASSWORD_MISMATCH);
                    confirmpassword.requestFocus();

                } else if (email1.length() == 0) {
                    email.setError(Constants.MISSING_EMAIL);
                    email.requestFocus();
                } else if (false == android.util.Patterns.EMAIL_ADDRESS.matcher(email1).matches()) {
                    email.setError(Constants.INVALID_MAIL);
                    email.requestFocus();


                } else if (mobile1.length() == 0) {
                    mobile.setError(Constants.MISSING_MOBILE);
                    mobile.requestFocus();


                } else if (mobile1.length() != 10) {
                    mobile.setError(Constants.INVALID_MOBILE);
                    mobile.requestFocus();

                } else {
                    db.insertEntry(username1,password1,confirmpassword1,email1,mobile1);

                    Toast.makeText(signup.this,"registered successfully",Toast.LENGTH_SHORT).show();

                    //SmsManager smsManager=SmsManager.getDefault();
                    //smsManager.sendTextMessage(n,null,user+pass,null,null);

                    Intent intent=new Intent(signup.this,loginpage.class);
                    startActivity(intent);


                }
            }

                public boolean isValidPassword(final String password)
                {
                    Pattern pattern;
                    Matcher matcher;
                    final String PASSWORD_PATTERN = "^(?=.*[0-8])(?=.*[*@#$%^&+=!])(?=\\S+$).{4,}$";
                    pattern = Pattern.compile(PASSWORD_PATTERN);
                    matcher = pattern.matcher(password);
                    return matcher.matches();
                }
        });
    }
}