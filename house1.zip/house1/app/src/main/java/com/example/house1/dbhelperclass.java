package com.example.house1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class dbhelperclass extends SQLiteOpenHelper {
    public static String database_name = "rocky4.db";
    public static String table_name = "house_table";
    public static String table_name1 = "LOGIN";
    public static String table_name2 = "O_LOGIN";


    public static String clo_1 = "owner_id";
    public static String clo_2 = "name";
    public static String clo_3 = "area_sqft";
    public static String clo_4 = "facilites";
    public static String clo_5 = "person_limit";
    public static String clo_6 = "address";
    public static String clo_7 = "price";
    public static String clo_8 = "mobile";
    public static String KEY_POTO = "poto";
    public static String clo_9="accept";
    public static String clo_10="type";
    public static String ID = "id";
    public static String USERNAME = "userName";
    public static String PASSWORD = "password";
    public static String CONFORM="conform";
    public static String Mobile = "mobile";
    public static String Email = "email";
    public static String ID1 = "id1";
    public static String USERNAME1 = "userName1";
    public static String PASSWORD1 = "password1";
    public static String CONFORM1="conform1";
    public static String Mobile1 = "mobile1";
    public static String Email1 = "email1";


    public dbhelperclass(Context context) {
        super(context, database_name, null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + table_name + "(owner_id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,area_sqft INTEGER,person_limit INTEGER,facilites TEXT,address TEXT,price TEXT,mobile TEXT,poto BLOB,accept INT,TYPE TEXT)");
        db.execSQL("create table " + table_name1 + "(id INTEGER PRIMARY KEY AUTOINCREMENT,userName TEXT,password TEXT,conform TEXT,email TEXT,mobile INTEGER)");
        db.execSQL("create table " + table_name2+ "(id1 INTEGER PRIMARY KEY AUTOINCREMENT,userName1 TEXT,password1 TEXT,conform1 TEXT,email1 TEXT,mobile1 INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL(" DROP TABLE IF EXISTS " + table_name);
        onCreate(db);
        db.execSQL(String.format("DROP TABLE IF EXISTS%s", table_name1));
        onCreate(db);
        db.execSQL(String.format("DROP TABLE IF EXISTS%s", table_name2));
        onCreate(db);


    }

    public void insertEntry(String userName, String password, String conformpass, String mobile, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues newValues = new ContentValues();
// Assign values for each row.
        newValues.put(USERNAME, userName);
        newValues.put(PASSWORD, password);
        newValues.put(CONFORM,conformpass);
        newValues.put(Email, email);
        newValues.put(Mobile, mobile);

// Insert the row into your table
        db.insert(table_name1, null, newValues);
    }

    public void insertEntry1(String userName1, String password1, String conformpass1, String mobile1, String email1) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues newValues = new ContentValues();
// Assign values for each row.
        newValues.put(USERNAME1, userName1);
        newValues.put(PASSWORD1, password1);
        newValues.put(CONFORM1,conformpass1);
        newValues.put(Email1, email1);
        newValues.put(Mobile1, mobile1);

// Insert the row into your table
        db.insert(table_name2, null, newValues);
    }




    public void addContacts(Contact contact) {
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues values = new ContentValues();

        values.put(clo_2, contact.getName());
        values.put(clo_3, contact.getArea_sqft());
        values.put(clo_4, contact.getPerson_limit());
        values.put(clo_5, contact.getFacilites());
        values.put(clo_6, contact.getAddress());
        values.put(clo_7, contact.getPrice());
        values.put(clo_8, contact.getMobile());
        values.put(clo_9,"null");
        values.put(KEY_POTO, contact.get_img());
        values.put(clo_10,contact.getType());


        db.insert(table_name, null, values);
        db.close();
    }


    /**
     * Getting All Contacts
     **/

    public List<Contact> getAllContacts() {
        List<Contact> contactList = new ArrayList<Contact>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + table_name;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Contact contact = new Contact();
                contact.set_id(Integer.parseInt(cursor.getString(0)));
                contact.setName(cursor.getString(1));
                contact.setArea_sqft(cursor.getString(2));
                contact.setPerson_limit(cursor.getString(3));
                contact.setFacilites(cursor.getString(4));
                contact.setAddress(cursor.getString(5));
                contact.setPrice(cursor.getString(6));
                contact.setMobile(cursor.getString(7));
                contact.set_img(cursor.getBlob(8));


                // Adding contact to list
                contactList.add(contact);
            } while (cursor.moveToNext());
        }

        // return contact list
        return contactList;
    }




    public List<Contact> getAllContacts1() {
        List<Contact> contactList = new ArrayList<Contact>();
        // Select All Query

        String selectQuery = "SELECT  * FROM " + table_name;

        SQLiteDatabase db = this.getWritableDatabase();
        //Cursor cursor = db.rawQuery("SELECT * FROM " + table_name + " WHERE " + clo_1 + " = ?;", new String[]{name});
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                if(cursor.getInt(9)==1) {

                    Contact contact = new Contact();
                    contact.set_id(Integer.parseInt(cursor.getString(0)));
                    contact.setName(cursor.getString(1));
                    contact.setArea_sqft(cursor.getString(2));
                    contact.setPerson_limit(cursor.getString(3));
                    contact.setFacilites(cursor.getString(4));
                    contact.setAddress(cursor.getString(5));
                    contact.setPrice(cursor.getString(6));
                    contact.setMobile(cursor.getString(7));
                    contact.set_img(cursor.getBlob(8));


                    // Adding contact to list
                    contactList.add(contact);
                }//end if()
            } while (cursor.moveToNext());
        }

        // return contact list
        return contactList;
    }



    public List<Contact> getAllContacts2() {
        List<Contact> contactList = new ArrayList<Contact>();
        // Select All Query

        String selectQuery = "SELECT  * FROM " + table_name;

        SQLiteDatabase db = this.getWritableDatabase();
        //Cursor cursor = db.rawQuery("SELECT * FROM " + table_name + " WHERE " + clo_1 + " = ?;", new String[]{name});
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                if(cursor.getInt(9)==1) {
                    if (cursor.getString(10)=="1bhk") {
                        Contact contact = new Contact();
                        contact.set_id(Integer.parseInt(cursor.getString(0)));
                        contact.setName(cursor.getString(1));
                        contact.setArea_sqft(cursor.getString(2));
                        contact.setPerson_limit(cursor.getString(3));
                        contact.setFacilites(cursor.getString(4));
                        contact.setAddress(cursor.getString(5));
                        contact.setPrice(cursor.getString(6));
                        contact.setMobile(cursor.getString(7));
                        contact.set_img(cursor.getBlob(8));


                        // Adding contact to list
                        contactList.add(contact);
                    }//end if()
                }
            } while (cursor.moveToNext());
        }

        // return contact list
        return contactList;
    }



    public Integer deletdata(String owner_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(table_name, "owner_id=?", new String[]{owner_id});
    }

    public boolean updateData(String owner_id, String name, String area_sqft, String facilities, String person_limit, String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contvalue = new ContentValues();
        contvalue.put(clo_1, owner_id);
        contvalue.put(clo_2, name);
        contvalue.put(clo_3, area_sqft);
        contvalue.put(clo_4, facilities);
        contvalue.put(clo_5, person_limit);
        contvalue.put(clo_6, address);
        db.update(table_name, contvalue, "owner_id=?", new String[]{owner_id});
        return (true);
    }


    public String getSinlgeEntry(String userName) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(table_name1, null, " USERNAME=?", new String[]{userName}, null, null, null);
        if (cursor.getCount() < 1) // UserName Not Exist
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        String password = cursor.getString(cursor.getColumnIndex(PASSWORD));
        cursor.close();
        return password;
    }


    public String getSinlgeEntry1(String userName1) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(table_name2, null, " USERNAME1=?", new String[]{userName1}, null, null, null);
        if (cursor.getCount() < 1) // UserName Not Exist
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        String password = cursor.getString(cursor.getColumnIndex(PASSWORD1));
        cursor.close();
        return password;
    }


    public String getdata() {

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cr = db.rawQuery("select * from " + table_name, null);

        String strb = "";
        while (cr.moveToNext()) {
            strb = strb +
                    "id:" + cr.getString(0) + "\n" +
                    "Name:" + cr.getString(1) + "\n" +
                    "area_sqft:" + cr.getInt(2) + "\n" +
                    "facilities:" + cr.getString(3) + "\n" +
                    "person_limit:" + cr.getInt(4) + "\n" +
                    "address:" + cr.getString(5) + "\n" +
                    "price:" + cr.getString(6) + "\n" +
                    "mobile:" + cr.getString(7) + "\n\n";
        }
        db.close();


        return strb;


    }


    public String getdata1(String name) {


        SQLiteDatabase db = this.getReadableDatabase();
        //String query1="select * from house_table where name="+name;
        Cursor cr = db.rawQuery("SELECT * FROM " + table_name + " WHERE " + clo_1 + " = ?;", new String[]{name});
        //  Cursor cr = db.query(table_name, null, " clo_1=?", new String[]{name}, null, null, null);
        //Cursor cr = db.rawQuery(query1, null);

        String strb = "";
        //   while (cr.moveToNext()) {
        cr.moveToNext();
//strb=strb="id=>"+cr.getInt(0)+"name=>"+cr.getString(1);
//        cr.moveToFirst();
        strb = strb +
		            "id:" + cr.getString(0) + "\n" +
                    "Name:" + cr.getString(1) + "\n" +
                    "area_sqft:" + cr.getInt(2) + "\n" +
                    "facilities:" + cr.getString(3) + "\n" +
                    "person_limit:" + cr.getInt(4) + "\n" +
                    "address:" + cr.getString(5) + "\n" +
                    "price:" + cr.getString(6) + "\n" +
                    "mobile:" + cr.getString(7) + "\n\n";
		
                

//        }
        db.close();


        return strb;


    }



    public String getdata2(String name) {


        SQLiteDatabase db = this.getReadableDatabase();
        //String query1="select * from house_table where name="+name;
        Cursor cr = db.rawQuery("SELECT * FROM " + table_name + " WHERE " + clo_1 + " = ?;", new String[]{name});
        //  Cursor cr = db.query(table_name, null, " clo_1=?", new String[]{name}, null, null, null);
        //Cursor cr = db.rawQuery(query1, null);

        String strb = "";
          while (cr.moveToNext()) {
      //  cr.moveToNext();
//strb=strb="id=>"+cr.getInt(0)+"name=>"+cr.getString(1);
//        cr.moveToFirst();
             int accept_status =cr.getInt(9);
             if(accept_status==1) {
                 strb = strb +
                    "id:" + cr.getString(0) + "\n" +
                    "Name:" + cr.getString(1) + "\n" +
                    "area_sqft:" + cr.getInt(2) + "\n" +
                    "facilities:" + cr.getString(3) + "\n" +
                    "person_limit:" + cr.getInt(4) + "\n" +
                    "address:" + cr.getString(5) + "\n" +
                    "price:" + cr.getString(6) + "\n" +
                    "mobile:" + cr.getString(7) + "\n\n";
             }//end if()
          }//end while()
        db.close();


        return strb;


    }


















    public boolean updateaccept(String owner_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contvalue = new ContentValues();
        contvalue.put(clo_9, 1);

        db.update(table_name, contvalue, "owner_id=?", new String[]{owner_id});
        return (true);
    }

    public boolean updatereject(String owner_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contvalue = new ContentValues();
        contvalue.put(clo_9, 0);

        db.update(table_name, contvalue, "owner_id=?", new String[]{owner_id});
        return (true);
    }


}




