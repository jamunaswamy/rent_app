package com.example.house1;

import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class house extends AppCompatActivity {
    TextView t1,t2,t3,t4,t5,t6,t7;
    EditText ed1,ed2,ed3,ed4,ed5,ed6,ed7,ed8;
    Button b1,b2,b3;
    dbhelperclass loginDataBaseAdapter;

    ImageView pic;

    String name,area_sqft,person_limit,facilities,address,price,mobile,type;
    ListView lv;
    dataAdapter data;
    Contact dataModel;
    Bitmap bp;
    byte[] photo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_house);

        loginDataBaseAdapter=new dbhelperclass(this);





        ed2=(EditText)findViewById(R.id.editText2);
        ed3=(EditText)findViewById(R.id.editText3);
        ed4=(EditText)findViewById(R.id.editText4);
        ed5=(EditText)findViewById(R.id.editText5);
        ed6=(EditText)findViewById(R.id.editText6);
        ed7=(EditText)findViewById(R.id.price);
        ed8=(EditText)findViewById(R.id.mobile);
        ed1=(EditText)findViewById(R.id.house_type);



        pic= (ImageView) findViewById(R.id.pic);

    }

    public void buttonClicked(View v){
        int id=v.getId();

        switch(id){

            case R.id.save:

                if(ed2.getText().toString().trim().equals("")&&ed3.getText().toString().trim().equals("")&&ed4.getText().toString().trim().equals("")&&ed5.getText().toString().trim().equals("")&&ed6.getText().toString().trim().equals("")&&ed7.getText().toString().trim().equals("")&&ed8.getText().toString().trim().equals("")&&ed1.getText().toString().trim().equals("")){
                    Toast.makeText(getApplicationContext(),"Name edit text is empty, Enter name", Toast.LENGTH_LONG).show();
                }  else{
                    addContact();
                }

                break;


            case R.id.pic:
                selectImage();
                break;
        }
    }

    public void selectImage(){
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        startActivityForResult(photoPickerIntent, 2);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch(requestCode) {
            case 2:
                if(resultCode == RESULT_OK){
                    Uri choosenImage = data.getData();

                    if(choosenImage !=null){

                        bp=decodeUri(choosenImage, 400);
                        pic.setImageBitmap(bp);
                    }
                }
        }
    }


    //COnvert and resize our image to 400dp for faster uploading our images to DB
    protected Bitmap decodeUri(Uri selectedImage, int REQUIRED_SIZE) {

        try {

            // Decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage), null, o);

            // The new size we want to scale to
            // final int REQUIRED_SIZE =  size;

            // Find the correct scale value. It should be the power of 2.
            int width_tmp = o.outWidth, height_tmp = o.outHeight;
            int scale = 1;
            while (true) {
                if (width_tmp / 2 < REQUIRED_SIZE
                        || height_tmp / 2 < REQUIRED_SIZE) {
                    break;
                }
                width_tmp /= 2;
                height_tmp /= 2;
                scale *= 2;
            }

            // Decode with inSampleSize
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            return BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage), null, o2);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    //Convert bitmap to bytes
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR1)
    private byte[] profileImage(Bitmap b){

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 0, bos);
        return bos.toByteArray();

    }



    // function to get values from the Edittext and image
    private void getValues(){
        name = ed2.getText().toString();
        area_sqft=ed3.getText().toString();
        person_limit=ed4.getText().toString();
        facilities=ed5.getText().toString();
        address=ed6.getText().toString();
        price=ed7.getText().toString();
        mobile=ed8.getText().toString();
        type=ed1.getText().toString();

        photo = profileImage(bp);
    }

    //Insert data to the database
    private void addContact(){
        getValues();

        loginDataBaseAdapter .addContacts(new Contact(name,area_sqft,person_limit,facilities,address,price,mobile, photo,type));
        Toast.makeText(getApplicationContext(),"Saved successfully", Toast.LENGTH_LONG).show();
    }
    }

